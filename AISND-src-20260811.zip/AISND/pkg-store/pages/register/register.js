// pkg-store/pages/register/register.js —— M3.1 库房注册
// R21：分区动态输入 + org-cascading-picker 两级联动选择（单位 → 项目部）
const api = require('../../../utils/api');
const network = require('../../../utils/network');

Page({
  data: {
    name: '',
    keeper: '',
    keeperOpenid: '',
    submitting: false,
    // 组织树（传给 org-cascading-picker，不再手动解析层级）
    orgTree: [],
    selectedUnitId: '',  // 选中的单位 _id（回显用）
    selectedDeptId: '',  // 选中的项目部 _id（回显用）
    orgId: '',           // 最终提交的 orgId（项目部 _id，或单位 _id）
    // 分区动态数组
    zones: [''],
    // 已注册库房列表
    storeList: [],
  },

  async onLoad() {
    try {
      const tree = await api.getOrgTree();
      this.setData({ orgTree: tree || [] });
    } catch (e) {
      this.setData({ orgTree: [] });
    }
    this.loadStoreList();
  },

  async loadStoreList() {
    try {
      const storeList = await api.getStoreList().catch(() => []);
      this.setData({ storeList });
    } catch (e) {
      // 静默失败
    }
  },

  bindName(e) { this.setData({ name: e.detail.value }); },
  onKeeperChange(e) {
    this.setData({
      keeper: e.detail.displayName || '',
      keeperOpenid: e.detail.openid || '',
    });
  },

  // org-cascading-picker 选择变更（替代 onUnitPick + onSubPick）
  onOrgChange(e) {
    this.setData({
      orgId: e.detail.orgId || '',
      selectedUnitId: e.detail.unitId || '',
      selectedDeptId: e.detail.deptId || '',
    });
  },

  // 分区动态行：追加 / 删除 / 更新
  addZone() {
    const zones = this.data.zones.slice();
    zones.push('');
    this.setData({ zones });
  },
  removeZone(e) {
    const idx = Number(e.currentTarget.dataset.index);
    const zones = this.data.zones.slice();
    if (zones.length <= 1) {
      zones[0] = '';
    } else {
      zones.splice(idx, 1);
    }
    this.setData({ zones });
  },
  bindZone(e) {
    const idx = Number(e.currentTarget.dataset.index);
    const zones = this.data.zones.slice();
    zones[idx] = e.detail.value;
    this.setData({ zones });
  },

  async onDeleteStore(e) {
    const id = e.currentTarget.dataset.id;
    const confirm = await wx.showModal({ title: '确认删除', content: '删除后不可恢复' }).catch(() => ({ confirm: false }));
    if (!confirm.confirm) return;
    try {
      await api.deleteStore(id);
      wx.showToast({ title: '已删除', icon: 'success' });
      await this.loadStoreList();
    } catch (err) { wx.showToast({ title: '删除失败', icon: 'none' }); }
  },

  async onSubmit() {
    try { await network.requireOnline(); } catch (e) { return; }
    const { name, orgId, keeper, keeperOpenid, zones } = this.data;
    if (!name) { wx.showToast({ title: '请填写库房名称', icon: 'none' }); return; }
    if (!orgId) { wx.showToast({ title: '请选择所属组织', icon: 'none' }); return; }
    if (!keeper) { wx.showToast({ title: '请填写管理员', icon: 'none' }); return; }
    const zoneList = (zones || []).map((z) => (z || '').trim()).filter(Boolean);
    this.setData({ submitting: true });
    try {
      await api.registerStore({ name, orgId, zone: zoneList, keeper, keeperOpenid });
      wx.showToast({ title: '注册成功', icon: 'success' });
      this.setData({ name: '', keeper: '', keeperOpenid: '', zones: [''] });
      this.loadStoreList();
    } catch (err) {
      wx.showToast({ title: '注册失败', icon: 'none' });
    } finally {
      this.setData({ submitting: false });
    }
  },
});
