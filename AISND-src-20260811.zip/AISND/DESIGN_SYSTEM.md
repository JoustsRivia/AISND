# SND 小程序设计系统（扩展规范 v3）

> 本文档在既有 `app.wxss` 统一设计系统（"深蓝科技感 + 卡片化层次"）基础上**拓展为更完整、更有意图的工业安全语言**。
> 设计方向：**工业安全仪表盘风**——稳重、可信、状态可读；把"后端能力"翻译成用户一眼能懂的视觉信号。
> 适用约束：小程序 WXSS 为 CSS 子集（支持 CSS 变量、渐变、关键帧动画、`tabular-nums`；**不支持** `container query` / `clamp()` 流体 / 部分 `oklch`；自定义字体需 `wx.loadFontFace`）。
> **v3 新增**：§7 布局与对齐规范、§8 交互与触控规范、§9 可见性规范、§10 视觉一致性规范（对应 2026-08-11 全站 UI 审查后修复项，详见 `ITERATION_REPORT.md`）。

---

## 1. 设计原则

1. **状态即信息**：颜色首先服务"安全状态语义"（合格/在用/待检/异常/停用），而非品牌装饰。每个卡片/列表项用**左侧状态轨**表达状态。
2. **拒绝 emoji 图标**：emoji 是第一 AI-slop 标志。统一使用线性图标（Iconfont 字体或内联 SVG 组件），九宫格与工具栏立即高级。
3. **数字即仪表**：指标/计数使用等宽数字（`tabular-nums`）+ 展示字体（DIN / IBM Plex Mono 类，经 `wx.loadFontFace` 加载），呈现"仪表盘"质感。
4. **克制动效**：状态切换用 `ease-out-quart/expo`，不回弹；进场错峰 `fadeIn`。绝不动画化布局属性（width/height/top/left）。
5. **节奏而非堆砌**：用变化的间距创造呼吸感，避免"万物皆卡片、卡片套卡片"。分区之间用更大留白与细分隔线。
6. **可见即可用**：高频任务首屏可达；任何需要后端数据的入口都显示实时状态，让用户感知"系统在干活"。

---

## 2. 设计令牌（Design Tokens）

### 2.1 色彩

| 类别 | 令牌 | 值 | 用途 |
|---|---|---|---|
| 品牌 | `--c-primary` | `#1A56DB` | 主操作、强调 |
| 品牌 | `--c-primary-2` | `#2563EB` | 渐变收尾 |
| 品牌 | `--c-hero-grad` | `160deg, #0F2B5B→#1A56DB→#2563EB` | 首页 Hero / 顶部 |
| 表面 | `--c-bg` | `#F5F7FA` | 页面底 |
| 表面 | `--c-card` / `--c-surface` / `--c-surface-2` | `#FFF` / `#F3F4F6` / `#F8FAFC` | 卡片/次级/凹陷 |
| 表面 | `--c-border` / `--c-divider` | `#E5E7EB` / `#EEF1F5` | 描边/分隔 |
| 文字 | `--c-text` / `-sub` / `-muted` / `-weak` | `#1F2937`/`#374151`/`#6B7280`/`#9CA3AF` | 主/次/弱/占位 |
| **状态-合格** | `--c-qualified` `#059669` / `-bg` `#E6F7EE` / `-tint` `#E7F8EC` | 合格、在用、正常 |
| **状态-在用** | `--c-inuse` `#2563EB` / `-bg` `#E8F0FE` / `-tint` `#EAF3FB` | 领用中、进行中 |
| **状态-待检** | `--c-pending` `#D97706` / `-bg` `#FFF7ED` / `-tint` `#FFF3E0` | 待审批、待检、临期 |
| **状态-异常** | `--c-abnormal` `#DC2626` / `-bg` `#FEF2F2` / `-tint` `#FFE9E7` | 异常、禁用、逾期 |
| **状态-维保** | `--c-maint` `#7C3AED` / `-bg` `#F5F3FF` / `-tint` `#EFEAFD` | 维修/保养中 |
| **状态-报废** | `--c-scrapped` `#6B7280` / `-bg` `#F3F4F6` / `-tint` `#ECEEF1` | 已报废、停用 |

> 与既有 `--c-success/-warning/-danger/-info` 并存（向后兼容）；新增 `--c-qualified/-inuse/-pending/-abnormal/-maint/-scrapped` 用于"器具/任务状态"语义，避免滥用 brand 蓝。

### 2.2 圆角 / 间距 / 阴影 / 字号
沿用既有 `--r-*`、`--sp-*`、`--sh-*`、`--fs-*`，新增：

| 令牌 | 值 | 用途 |
|---|---|---|
| `--r-2xl` | `40rpx` | 大卡片 / 面板 |
| `--sp-7` | `80rpx` | 分区大留白 |
| `--sh-rail` | `inset 3rpx 0 0` 状态色 | 卡片左侧状态轨 |
| `--ease-out` | `cubic-bezier(0.22,1,0.36,1)` | 指数缓出（替代 bounce） |
| `--dur-fast/-base/-slow` | `160ms`/`280ms`/`420ms` | 动效时长 |

### 2.3 字体
- 正文：沿用系统字体栈（`PingFang SC`）。
- 展示/数字：`.t-display`（等宽数字字体，经 `wx.loadFontFace` 加载 `@font/IBM-Plex-Mono` 或本地 DIN），配合 `.t-num` 的 `tabular-nums`。
- 字号新增 `--fs-hero` `72rpx`（Hero 大数）、`--fs-display` `56rpx`（看板指标）。

---

## 3. 组件规范

### 3.1 卡片（带状态轨）
```css
.card--status { position: relative; }
.card--status::before {
  content:''; position:absolute; left:0; top:0; bottom:0; width:6rpx;
  border-radius: var(--r-md) 0 0 var(--r-md); background: var(--rail, var(--c-inuse));
}
```
状态由 `data-status`（`qualified/inuse/pending/abnormal/maint/scrapped`）驱动 `--rail` 取值。

### 3.2 九宫格模块 tile
- 图标：线性图标字体（非 emoji），48rpx，置于 96rpx 圆角底（tint 色）。
- 标签：28rpx 中等字重。
- **状态徽标**：tile 右上角红点/数字徽标（见 3.3），数据来自后端聚合。
- 选中/按压：底色 `--c-primary-soft` + 轻微 `scale(0.97)`（`--ease-out`）。

### 3.3 徽标 / 药丸（Badge / Pill）
- `.badge`：右上角圆形数字（待办数），>99 显示 `99+`。
- `.pill--{qualified|inuse|pending|abnormal|maint|scrapped}`：状态文字标签。
- 红点 `.dot`：`width:16rpx;height:16rpx;border-radius:50%;background:var(--c-abnormal)`。

### 3.4 流程时间线（Stepper / Timeline）
```css
.flow { /* 纵向左轨 + 节点 */ }
.flow-node { width:40rpx;height:40rpx;border-radius:50%;border:4rpx solid var(--c-border); }
.flow-node--done { border-color:var(--c-qualified); background:var(--c-qualified); }
.flow-node--active { border-color:var(--c-inuse); box-shadow:0 0 0 6rpx var(--c-inuse-tint); }
.flow-node--wait { border-color:var(--c-pending); }
.flow-line { width:4rpx; background:linear-gradient(var(--c-qualified),var(--c-border)); }
```
用于：领用→归还、报修→维修→复检、采购→验收→入库、报废→审批→处置。每节点对应一个云函数动作，当前态上色。

### 3.5 图表（看板）
- 使用 `ec-canvas`（ECharts 小程序版）绘制：状态分布（饼）、领用归还趋势（线）、隐患趋势（柱）、临期清单（列表+进度环）。
- 图表配色取自状态令牌，禁用"青+紫蓝渐变"AI 配色。

### 3.6 空 / 错误 / 加载态
- 空态：图标（线性）+ 一句引导文案 + 主操作（渐进式披露，不重复已有信息）。
- 加载：`fadeIn` + 骨架屏（shimmer 用 `--c-surface-2` 渐变，禁用发光）。

---

## 4. 可访问性（户外 / 戴手套场景）
- **对比度**：正文 `#1F2937` on `#FFF` 达标；状态色文字需配 `-bg` 底，避免浅色字直接压浅底。
- **最小触控**：按钮/可点项 ≥ `88rpx` 高（沿用 `.btn` 88rpx）。
- **弱网/强光**：Hero 与关键指标用高对比；状态用色+形状双编码（色块+文字/图标），不仅靠颜色区分。

---

## 5. 主题与夜间
- 所有令牌定义在 `page` 上，预留 `page.dark` 覆盖集（深色作业终端风可选）：仅覆盖 `--c-bg/--c-card/--c-text/--c-border` 与状态 `-bg`，其余令牌复用。
- 切换：在 `app.js` 全局 `data.theme` 控制 `page` 类，组件不各自硬编码颜色。

---

## 6. 落地清单（按优先级）
1. **[标准]** 本文档 + `app.wxss` 增强 tokens/工具类（本版交付）。
2. **[P0 可视化]** 九宫格模块 tile 实时状态徽标（后端聚合 `homeStatus` → 前端渲染）。**已完成**：`cloudfunctions/stats` 新增 `homeStatus` action（8 个模块待办计数，tone 仅表语义）；`utils/api.js` 导出 `getHomeStatus`；`pages/index` 取数并 `attachBadges` 挂到 tile，`index.wxml` 渲染 `.badge.badge--{tone}`（>99 显示 `99+`），`index.wxss` 定位 + 白边隔离。

> 映射：消息预警=未读预警(abnormal) / 周期试验=待检器具(pending) / 器具台账=临期器具(pending) / 维保报修=待审批报修(pending) / 报废管理=待审批报废(pending) / 监督检查=待整改隐患(abnormal) / 采购验收=待审批采购(pending) / 库房管理=盘亏器具(abnormal)。仅在有积压时显示徽标（节奏而非堆砌）。
3. **[P1]** 四个核心流程时间线组件（领用归还/报修复检/采购入库/报废处置）。**已完成**：`utils/flow.js` 新增 `FLOWS` 映射（四流程 `labels` + `current(status)` 推导）与 `buildFlow(type, status, meta)`（驳回态 `rejected` 将 current 钳到 0）；`components/flow-steps` 纯 CSS 令牌 stepper 组件（done/active/wait/reject 节点 + 连接线，✓/! 标记，无外部依赖）。接入四处：
   - `pkg-maint/pages/repair` → 报修复检（标题"处理进度"，select-to-expand）；
   - `pkg-scrap/pages/approve` → 报废处置（标题"处置进度"，点击行展开）；
   - `pkg-purchase/pages/approve` → 采购入库（标题"采购进度"，保留原 `record-timeline` 操作日志）；
   - `pages/tool-detail` → 领用→归还（独立"使用状态"卡片，置于时间线前）。
4. **[P1]** 统计驾驶舱图表化。**已完成（实现与原文偏差）**：原文指定 ec-canvas，但为规避其 ~1MB 依赖 + 外链网络/离线风险（现场弱网工具不宜引入），改用**原生 canvas 2d 自建 `components/chart` 组件**（支持 bar/line/pie，配色取自状态令牌，无第三方依赖）。`pkg-stats/pages/dashboard` 用 `getDashboard()` 状态分布 → pie（合格/待检/维修中/缺失/报废），近 7 日 `getTrend()` → line；移除旧 CSS 趋势占位。
5. **[P2]** 图标字体替换 emoji；展示字体加载；夜间主题。**已完成**：
   - 夜间主题：`utils/theme.js`（`auto`/`dark` 持久化）+ `@media (prefers-color-scheme: dark)`（自动，覆盖全部页面）与 `.theme-dark` 手动类（profile 开关持久化，覆盖 opted-in 页面根视图）；`app.wxss` 双份令牌块（内容与作用域一致）。
   - 字体脚手架：`utils/fonts.js` 用 `wx.loadFontFace` 静默加载 `SNDNum`（等宽数字，默认 jsdelivr `@fontsource/roboto-mono`，失败回退系统等宽栈）+ 可选 `SNDIcon`（图标字体，`ICONFONT_URL` 留空即跳过）；`app.onLaunch` 调用；`app.wxss` 新增 `--font-num` 令牌与 `.font-num`/`.font-display`/`.iconfont` 类。**emoji 图标暂保留**，图标字体接入路径见 `utils/fonts.js` 顶部注释（iconfont.cn 导出 .ttf → 填 URL → wxml 改 `.iconfont` 文本）。

> 所有页面/组件只引用令牌与工具类，**禁止硬编码色值**（除一次性渐变），换肤/调性只需改 `app.wxss`。

---

## 7. 布局与对齐规范（v3 新增）

> 目标：消灭"元素排列混乱堆积"。全站间距、对齐、层级必须统一到令牌尺度，杜绝魔法数字。

### 7.1 间距只认令牌（禁止魔法数字）
- 一律使用 `--sp-1..7`（8/16/24/32/48/64/80rpx），禁止裸写 `10rpx / 14rpx / 18rpx / 20rpx / 22rpx / 30rpx / 36rpx` 等非尺度值。
- 组件**内部**边距用自身 padding；组件**外部**间距由父容器 margin 控制，**组件自身不得携带 `margin`**（否则卡片套卡片时产生双外边距——已修复 `flow-steps`、`record-timeline`、`stats-card` 的历史问题）。
- 同层元素间距优先用 flex `gap`（`--sp-*`），避免逐个 margin。

### 7.2 对齐规则
- 同一卡片/区块内的文本、图标、数值**垂直居中对齐**；数值右对齐时保持 `tabular-nums`。
- 区块标题体系固定为三种：`section-head`（主区块）、`card-title`（卡片内）、`mod-group-title`（分组），不得自创同级样式。
- 状态标签（`status-tag` / `pill`）一律置于行尾或标题右侧，`align-items: center`。

### 7.3 层级关系
- **操作密度**：一行最多 3 个等宽操作；超过 3 个（如台账"录入/导入/高危专项/导出台账"）改 **2×2 网格**或横向滚动，不得 `flex:1` 硬挤（已修复 ledger）。
- **嵌套深度**：卡片内不再套卡片。若需内嵌面板，用 `--c-surface-2` 底 + `--r-sm` 圆角的 `panel` 类，而非再套 `.card`。
- **z-index 纪律**：sticky 顶栏 `10`、FAB `50`、底部工具栏 `40`、批量操作栏 `100`；禁止页面自造大数值。

---

## 8. 交互与触控规范（v3 新增）

> 目标：消灭"交互不直观"。触控目标、反馈、入口全部可预期。

### 8.1 最小触控目标 88rpx（硬性）
- 所有可点元素（按钮、chip、行、tab、picker、眼睛图标）**高度 ≥ 88rpx**，宽度 ≥ 88rpx。
- **禁止 `size="mini"` 原生按钮**承载关键操作（审批/登记/复检等）；统一为 `.btn`（88rpx）或 `.btn-sm`（72rpx，仅非关键次级操作）。
- 已修复：`filter-bar` tab/chip、`ledger` 操作按钮、`message` 操作组、`login` 密码显隐。
- 触碰反馈：可点项统一加 `hover-class`（轻缩放 `scale(0.98)` 或底色变化），禁用元素 `opacity: 0.5`。

### 8.2 操作分组与引导
- 操作区固定为三种形态之一：
  - `.btn` 主按钮（唯一主操作，渐变蓝）
  - `.chip-group` 次级操作组（浅底胶囊，多选/筛选）
  - `.toolbar` 底部操作栏（详情页，≤3 个，主操作右置）
- 每屏只允许 **1 个主操作**（渐变蓝），其余为次级，避免视觉争抢。
- 空态必须带主操作引导（"＋ 手动录入一台器具"式），渐进式披露。

### 8.3 状态与反馈
- 加载中：`loading` 文案 + `fade-in` 骨架；按钮 `loading="{{acting}}" disabled` 防重复提交。
- 成功/失败：沿用 `toast`（不新造弹层）。
- 批量模式（如消息管理）：进入后显示 `batch-bar`，顶部"管理/取消"高亮切换态。

---

## 9. 可见性规范（v3 新增）

> 目标：消灭"内容不可见"。关键内容与操作在任何主题、任何尺寸下都清晰可达。

### 9.1 对比度与配色纪律
- 正文 `--c-text` on `--c-card` 达标；**状态色文字必须配 `-bg` 底**，禁止状态色直接压白底。
- **禁止硬编码色值**（`#fff/#333/#999/#f5f5f5/#e0e0e0/...` 一律换成令牌），否则深色模式下浅底灰字不可见（已修复 `user-picker` / `db-picker` / `org-cascading-picker` / `identity`）。
- 组件内 `color="#..."` 内联属性一律去掉，改用 CSS 类或令牌（已修复 profile 的 switch）。
- 内联 `style="color: {{...}}"` 仅允许状态语义色映射，且映射值来自令牌常量，不得绕过令牌。

### 9.2 深色模式
- 所有页面/组件必须随 `page` 变量或 `.theme-dark` 生效；底部固定栏用 `var(--c-card)` + `border-top`，**禁止 `rgba(255,255,255,0.96)` 白条**（已修复 tool-detail 工具栏）。
- 新组件合入前检查：无硬编码色值、无 `#fff` 底、图标对比度达标。

### 9.3 信息层级与截断
- 关键值（编号、状态、有效期）使用 `.t-num`/`.font-num`，弱信息用 `--c-text-weak`，**禁止用弱化灰承载必读信息**（如入库表单值）。
- 长文本统一 `.ellipsis`（单行）/`.ellipsis-2`（两行），关键行不换行截断。
- 首屏可达：高频操作（搜索、扫码、录入）在首屏可见，不依赖滚动。

---

## 10. 视觉一致性规范（v3 新增）

> 目标：消灭"视觉不美观/不一致"。全站一源、一眼可辨。

### 10.1 emoji 图标治理（逐步）
- 设计原则 2 已定"拒绝 emoji"。当前全站 emoji 为**已知技术债**：待 `SNDIcon` 图标字体接入（`utils/fonts.js` 顶部注释）后统一替换。
- 过渡期规则：emoji 只允许出现在"图标位"（圆底/胶囊内），**禁止**出现在正文、标题、按钮文字混排中；同一屏 icon 风格一致。
- 新增代码一律用线性图标占位（`.iconfont` 类 + 语义注释），不新增 emoji。

### 10.2 表单与页面样板统一
- 表单字段统一用 `form-field` 组件；无组件场景下表单样式**必须引用公共类**（`.form-row/.form-label/.form-value`，见 app.wxss §表单），禁止各页面重复定义（已治理 purchase/apply、tool-create、inbound、disposal、store/register 的重复样式）。
- 详情页统一"Hero + 信息卡 + 操作栏"三明治结构（参考 tool-detail）。
- 列表页统一"顶栏 + filter-bar + 卡片列表 + 空态"结构。

### 10.3 主题一致性
- 深色/浅色主题只改 `app.wxss` 令牌；页面禁止出现"深色下突兀"的局部样式。
- 动效统一 `--ease-out` + `--dur-*`，禁止页面自造 keyframes 名称冲突。

---

## 11. 落地清单（v3 增量）

1. **[已完成] 布局对齐**：`ledger` 操作区 2×2 网格 + 88rpx；`message` 操作组改 chip-group；`filter-bar` tab/chip 触控高度 88rpx；`flow-steps`/`record-timeline`/`stats-card` 去外部 margin。
2. **[已完成] 交互触控**：全站关键审批 mini 按钮提升触控；login 密码显隐 88rpx；message 批量管理入口 chip 化。
3. **[已完成] 可见性**：`user-picker`/`db-picker`/`org-cascading-picker` 硬编码色值迁移令牌（深色模式修复）；tool-detail 底部工具栏改 `--c-card`；profile switch 去硬编码色。
4. **[已完成] 一致性**：表单公共样式落地；emoji 治理规则写入本文档；identity 硬编码色迁移。
5. **[已替换，待云存储更新]** emoji 图标字体替换：52 场景图标子集化 `assets/fonts/snd-icon.ttf`（9.1KB）+ 映射 `snd-icon-map.json` + 图标类 `snd-icons.wxss`；`utils/fonts.js` 已填 `ICONFONT_FILEID`（云存储）；**全站 46 处 emoji 已替换**为 `<text class="iconfont">&#xXXXX;</text>`（19 页），密码显隐用伪元素类动态切换。**剩余动作**：用共享盘新版 `snd-icon.ttf`（52 图标）覆盖上传云存储同路径（fileID 不变）。
6. **[已完成]** 剩余 `size="mini"` 按钮巡检：12 页共 30+ 处已替换/清理（无自定义 class 的换 `.btn-sm`/`.btn-sm-primary`/`.btn-sm-danger`，有自定义 class 的去掉 size 由默认 button 高度兜底触控）；app.wxss 全局 `button[size="mini"]{min-height:88rpx}` 保留作为兜底。
7. **[已完成]** 表单重复样式统一：pkg-purchase/apply、pkg-ledger/tool-create、pkg-scrap/disposal、pkg-store/register 已迁移到全局 `.form-row/.form-label/.form-value/.form-input`（页面仅保留 col 变体、photo/lease/zones 等特有样式）。
